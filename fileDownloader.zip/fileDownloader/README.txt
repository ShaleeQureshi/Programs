Developed by: Shahrukh Qureshi

This program downloads a file from the internet.

-Necessary input = link address of the file

Website: https://shaleequreshi2019.wixsite.com/website
GitHub: https://github.com/ShaleeQureshi