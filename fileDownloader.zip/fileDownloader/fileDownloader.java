import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

/*
 Author: Shahrukh Qureshi 
 Date: April 4, 2020 
 Description: This program downloads a file from a given link and stores it in the user's downloads folder
*/
public class fileDownloader {
    private static final int BUFFER_SIZE = 4096;

    public static void fileDownload(String fileURL, String directory) {

        //Try Catch used in case an error occurs in the download
        try{
        URL url = new URL(fileURL); //Creating a URL object 

        HttpURLConnection httpConn = (HttpURLConnection) url.openConnection(); //Creating a connection

            String fileName = ""; //Declaring variable for the file's name

            int bytesRead = -1;
            byte[] buffer = new byte[BUFFER_SIZE]; // Array of bytes

            // If it cant get the name of the file from the header it will use the URL
            fileName = fileURL.substring(fileURL.lastIndexOf("/") + 1, fileURL.length());

            System.out.println("fileName = " + fileName);

            InputStream incomingData = httpConn.getInputStream(); // Opening input stream from the connection
            String saveFilePath = directory + File.separator + fileName; // Saving the filepath for the downloaded file
            FileOutputStream savingData = new FileOutputStream(saveFilePath); // Opens the output stream to save the data in the file

            // While the amount of bytes read is not equal to -1 (meaning completed) it will download
            while ((bytesRead = incomingData.read(buffer)) != -1) {
                savingData.write(buffer, 0, bytesRead); // Downloading the data and saving it to the output stream
            }

            savingData.close(); // Closing the output stream
            incomingData.close(); // Closing the input stream

            System.out.println("File sucessfully downloaded! It is in your downloads folder!"); // If it downloads then this will be outputted to the user

        httpConn.disconnect(); // Stopping the process
        }
        catch (IOException error){
            System.out.println("An error has occured with the download!");
        }

    }// fileDownload Method

    public static void main(String[] args) {

        String link; //String variable for the URL

        Scanner input = new Scanner (System.in); //Scanner object to get user input
        
        System.out.println("Please enter the link to the file"); //Prompting user for link to file
        link = input.nextLine(); //Reading the link
        
        fileDownload(link, System.getProperty("user.home") + "/Downloads" ); //Calling the fileDownload Method
        //System.getProperty("user.home") gets the user's home directory and adding "/Downloads" puts the filepath to the user's downloads folder 

        input.close(); //Closing the scanner 

    }// main Method
}