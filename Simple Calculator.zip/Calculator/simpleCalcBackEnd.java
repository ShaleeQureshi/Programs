import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/*
Author: Shalee Qureshi 
Date: March 31, 2020
Description: This class contains all of the methods that allows the functions for the basic calculator to operate

Method List:

1. whenOperationsUsed(JTextArea a, JLabel b) = This method fixes the issue between putting the info from the textarea to the label
2. setText(JTextArea a, String num) = This method sets the display text
3. returnType(double answer) = This method checks to see if there is a decimal in the answer (to return double or long based on it)
4. fixAnswer(double answer, JTextArea a) = This method fixes the final answer 
5. fixSign(String num) = This method fixes the sign of the strings (num- to -num)
6. double sum(double num1, double num2) = This method adds two values
7. double subtract (double num1, double num2) = This method subtracts two values
8. divide(double num1, double num2) = This method divides two values
9. multiply(double num1, double num2) = This method multiples two values
*/

public class simpleCalcBackEnd {

    static String oldStringValue;

    // This method fixes the issue between putting the info from the textarea to the
    // label
    public static void whenOperationsUsed(JTextArea a, JLabel b) {

        if (a.getText().contains("-")) {
            b.setText("-" + a.getText().replaceAll("-", ""));
        } else {
            b.setText(a.getText());
        }
        a.setText("0");

    }// whenOperationsUsed Method

    // This method sets the display text
    public static void setText(JTextArea a, String num) {

        if (a.getText().contains("0") && a.getText().length() == 1) {
            a.setText(num);
        } else {
            if (a.getText().contains("-")) {
                a.setText((a.getText() + num).replaceAll("-", "") + "-");
            } else {
                a.setText(a.getText() + num);
            }
        }

    }// setText Method

    // This method checks to see if there is a decimal in the answer (to return
    // double or long based on it)
    public static long returnType(double answer) {

        if (Math.round(answer) == answer) {
            return Math.round(answer);
        }

        return 1;

    }// returnType

    // This method fixes the final answer
    public static void fixAnswer(double answer, JTextArea a) {

        long type = returnType(answer);

        if (type != 1) {
            if (Integer.toString((int) answer).length() > 9) {
                a.setText("0");
                JOptionPane.showMessageDialog(null, "Your answer is:\n" + answer);
            } else {
                if (answer > 0) {
                    a.setText("" + Math.round(answer));
                } else {
                    a.setText(Math.abs(answer) + "-");
                }
            }

        } else {
            if (Integer.toString((int) answer).length() > 9) {
                a.setText("0");
                JOptionPane.showMessageDialog(null, "Your answer is:\n" + answer);
            } else {
                if (answer > 0) {
                    a.setText("" + answer);
                } else {
                    a.setText(Math.abs(answer) + "-");
                }
            }
        }

    }// fixAnswer Method

    // This method fixes the sign of the strings (num- to -num)
    public static String fixSign(String num) {

        if (num.contains("-")) {
            return "-" + num.replaceAll("-", "");
        } else {
            return num;
        }

    }// fixSign Method

    // This method adds two values
    public static double sum(double num1, double num2) {
        return num1 + num2;
    }// sum Method

    // This method subtracts two values
    public static double subtract(double num1, double num2) {
        return num1 - num2;
    }// subtract Method

    // This method divides two values
    public static double divide(double num1, double num2) {
        return num1 / num2;
    }// divide Method

    // This method multiplies two values
    public static double multiply(double num1, double num2) {
        return num1 * num2;
    }// multiply Method

}// class simpleCalcBackEnd
