import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Font;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import javax.swing.JOptionPane;

/* 
Author: Shalee Qureshi 
Date: March 31, 2020
Description: A basic calculator with the 4 basic operations (addition, subtraction, multiplication, division) and the option for plus/minus

Method List:

1. actionPerformed(ActionEvent e) = Performs a task when an action is invoked
2. mouseClicked(MouseEvent e) = Not used in this program
3. mousePressed(MouseEvent e) = Not used in this program
4. mouseReleased(MouseEvent e) = Not used in this program
5. mouseEntered(MouseEvent e) = Not used in this program
6. mouseExited(MouseEvent e) = Not used in this program

*/

public class simpleCalc extends JFrame implements ActionListener, MouseListener {

    // Declaring global variables

    JLabel lblAuthor, lblBeforeOperation;

    static JTextArea lblResult;

    JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0, btnClear, btnEqual, btnSubtract, btnAdd,
            btnDivide, btnMultiply, btnDot, btnPlusMinus;

    Font fontBtn;

    LineBorder border;

    Cursor handCursor;

    String operation;

    public simpleCalc() {

        // Initializing labels
        lblAuthor = new JLabel("Developed by Shahrukh Qureshi");
        lblBeforeOperation = new JLabel();

        // Initializing JTextArea
        lblResult = new JTextArea();

        // Initializing buttons
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        btn6 = new JButton("6");
        btn7 = new JButton("7");
        btn8 = new JButton("8");
        btn9 = new JButton("9");
        btn0 = new JButton("0");
        btnClear = new JButton("C");
        btnEqual = new JButton("=");
        btnSubtract = new JButton("-");
        btnAdd = new JButton("+");
        btnDivide = new JButton("÷");
        btnMultiply = new JButton("x");
        btnDot = new JButton(".");
        btnPlusMinus = new JButton("+/-");

        // Fonts
        fontBtn = new Font("Arial", Font.BOLD, 15);
        lblAuthor.setFont(new Font("Arial", Font.PLAIN, 7));

        // Cursor
        handCursor = new Cursor(Cursor.HAND_CURSOR);

        // Adding font to buttons
        btn1.setFont(fontBtn);
        btn2.setFont(fontBtn);
        btn3.setFont(fontBtn);
        btn4.setFont(fontBtn);
        btn5.setFont(fontBtn);
        btn6.setFont(fontBtn);
        btn7.setFont(fontBtn);
        btn8.setFont(fontBtn);
        btn9.setFont(fontBtn);
        btn0.setFont(fontBtn);
        btnClear.setFont(fontBtn);
        btnEqual.setFont(fontBtn);
        btnSubtract.setFont(fontBtn);
        btnAdd.setFont(fontBtn);
        btnDivide.setFont(fontBtn);
        btnMultiply.setFont(fontBtn);
        btnDot.setFont(fontBtn);
        btnPlusMinus.setFont(fontBtn);

        // Adding border
        border = new LineBorder(Color.BLACK);

        // Adding the border to the lbl
        lblResult.setBorder(border);

        // Setting JComponents (x, y, width, height) and adding them
        lblResult.setBounds(40, 15, 300, 50);
        lblResult.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        lblResult.setEditable(false);
        lblResult.setFont(new Font("Arial", Font.BOLD, 45));
        lblResult.setOpaque(false);
        lblResult.setText("0");
        add(lblResult);

        lblAuthor.setBounds(230, 255, 120, 100);
        add(lblAuthor);

        lblBeforeOperation.setBounds(40, 0, 300, 50);
        add(lblBeforeOperation);

        btn7.setBounds(40, 80, 50, 50);
        add(btn7);

        btn8.setBounds(100, 80, 50, 50);
        add(btn8);

        btn9.setBounds(160, 80, 50, 50);
        add(btn9);

        btn4.setBounds(40, 140, 50, 50);
        add(btn4);

        btn5.setBounds(100, 140, 50, 50);
        add(btn5);

        btn6.setBounds(160, 140, 50, 50);
        add(btn6);

        btn1.setBounds(40, 200, 50, 50);
        add(btn1);

        btn2.setBounds(100, 200, 50, 50);
        add(btn2);

        btn3.setBounds(160, 200, 50, 50);
        add(btn3);

        btnClear.setBounds(40, 260, 50, 50);
        add(btnClear);
        btnClear.setBackground(Color.RED);

        btn0.setBounds(100, 260, 50, 50);
        add(btn0);

        btnDot.setBounds(160, 260, 50, 50);
        add(btnDot);

        // Operations

        btnMultiply.setBounds(230, 100, 50, 50);
        btnMultiply.setBackground(Color.GRAY);
        add(btnMultiply);

        btnDivide.setBounds(290, 100, 50, 50);
        btnDivide.setBackground(Color.GRAY);
        add(btnDivide);

        btnSubtract.setBounds(230, 160, 50, 50);
        btnSubtract.setBackground(Color.GRAY);
        add(btnSubtract);

        btnAdd.setBounds(290, 160, 50, 50);
        btnAdd.setBackground(Color.GRAY);
        add(btnAdd);

        btnPlusMinus.setBounds(230, 220, 50, 50);
        btnPlusMinus.setFont(new Font ("Arial", Font.BOLD, 10));
        btnPlusMinus.setBackground(Color.GRAY);
        add(btnPlusMinus);

        btnEqual.setBounds(290, 220, 50, 50);
        btnEqual.setBackground(new Color(66, 191, 245));
        add(btnEqual);

        // Adding listeners/cursor to buttons
        btn0.addActionListener(this);
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        btn5.addActionListener(this);
        btn6.addActionListener(this);
        btn7.addActionListener(this);
        btn8.addActionListener(this);
        btn9.addActionListener(this);
        btnAdd.addActionListener(this);
        btnSubtract.addActionListener(this);
        btnPlusMinus.addActionListener(this);
        btnDivide.addActionListener(this);
        btnMultiply.addActionListener(this);
        btnEqual.addActionListener(this);
        btnClear.addActionListener(this);
        btnDot.addActionListener(this);

        btn0.addMouseListener(this);
        btn1.addMouseListener(this);
        btn2.addMouseListener(this);
        btn3.addMouseListener(this);
        btn4.addMouseListener(this);
        btn5.addMouseListener(this);
        btn6.addMouseListener(this);
        btn7.addMouseListener(this);
        btn8.addMouseListener(this);
        btn9.addMouseListener(this);
        btn0.addMouseListener(this);
        btnAdd.addMouseListener(this);
        btnSubtract.addMouseListener(this);
        btnPlusMinus.addMouseListener(this);
        btnDivide.addMouseListener(this);
        btnMultiply.addMouseListener(this);
        btnEqual.addMouseListener(this);
        btnClear.addMouseListener(this);
        btnDot.addMouseListener(this);

        btn0.setCursor(handCursor);
        btn1.setCursor(handCursor);
        btn2.setCursor(handCursor);
        btn3.setCursor(handCursor);
        btn4.setCursor(handCursor);
        btn5.setCursor(handCursor);
        btn6.setCursor(handCursor);
        btn7.setCursor(handCursor);
        btn8.setCursor(handCursor);
        btn9.setCursor(handCursor);
        btn0.setCursor(handCursor);
        btnAdd.setCursor(handCursor);
        btnSubtract.setCursor(handCursor);
        btnPlusMinus.setCursor(handCursor);
        btnDivide.setCursor(handCursor);
        btnMultiply.setCursor(handCursor);
        btnEqual.setCursor(handCursor);
        btnClear.setCursor(handCursor);
        btnDot.setCursor(handCursor);

        setSize(390, 370);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        setVisible(true);

    }// constructor

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btn1) {

            simpleCalcBackEnd.setText(lblResult, "1");

        } else if (e.getSource() == btn2) {

            simpleCalcBackEnd.setText(lblResult, "2");

        } else if (e.getSource() == btn3) {

            simpleCalcBackEnd.setText(lblResult, "3");

        } else if (e.getSource() == btn4) {

            simpleCalcBackEnd.setText(lblResult, "4");

        } else if (e.getSource() == btn5) {

            simpleCalcBackEnd.setText(lblResult, "5");

        } else if (e.getSource() == btn6) {

            simpleCalcBackEnd.setText(lblResult, "6");

        } else if (e.getSource() == btn7) {

            simpleCalcBackEnd.setText(lblResult, "7");

        } else if (e.getSource() == btn8) {

            simpleCalcBackEnd.setText(lblResult, "8");

        } else if (e.getSource() == btn9) {

            simpleCalcBackEnd.setText(lblResult, "9");

        } else if (e.getSource() == btn0 && lblResult.getText().length() != 0) {

            simpleCalcBackEnd.setText(lblResult, "0");

        } else if (e.getSource() == btnClear) {

            lblResult.setText("0");
            lblBeforeOperation.setText("");

        } else if (e.getSource() == btnDot && !lblResult.getText().contains(".")) {

            lblResult.setText(lblResult.getText() + ".");

        } else if (e.getSource() == btnAdd) {

            simpleCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "add";

        } else if (e.getSource() == btnSubtract) {

            simpleCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "subtract";

        } else if (e.getSource() == btnDivide) {

            simpleCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "divide";

        } else if (e.getSource() == btnMultiply) {

            simpleCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "multiply";

        } else if (e.getSource() == btnPlusMinus) {

            if (!lblResult.getText().contains("-")) {
                lblResult.setText(lblResult.getText() + "-");
            } else {
                lblResult.setText(lblResult.getText().replaceAll("-", ""));
            }

        }
        if (e.getSource() == btnEqual) {

            double answer;
            String beforeSignFixed;

            try {
                if (operation.equals("add")) {

                    beforeSignFixed = simpleCalcBackEnd.fixSign(lblResult.getText());

                    answer = simpleCalcBackEnd.sum(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    simpleCalcBackEnd.fixAnswer(answer, lblResult);

                } else if (operation.equals("subtract")) {

                    beforeSignFixed = simpleCalcBackEnd.fixSign(lblResult.getText());

                    answer = simpleCalcBackEnd.subtract(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    simpleCalcBackEnd.fixAnswer(answer, lblResult);

                } else if (operation.equals("divide")) {

                    beforeSignFixed = simpleCalcBackEnd.fixSign(lblResult.getText());

                    answer = simpleCalcBackEnd.divide(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    simpleCalcBackEnd.fixAnswer(answer, lblResult);

                } else if (operation.equals("multiply")) {

                    beforeSignFixed = simpleCalcBackEnd.fixSign(lblResult.getText());

                    answer = simpleCalcBackEnd.multiply(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    simpleCalcBackEnd.fixAnswer(answer, lblResult);

                }
            } catch (Exception error) {
                dispose();
                JOptionPane.showMessageDialog(null, "An Unexpected Error has occured.\nThe Program will now restart.");
                new simpleCalc();
            }

        }

    }// actionPerformed Method

    public void mouseClicked(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public static void main(String[] args) {

        new simpleCalc();

    }// main Method

}// class simpleCalc
