This is a simple calculator developed by Shahrukh Qureshi
-Run this program through the simpleCalc.java file

Website: https://shaleequreshi2019.wixsite.com/website
GitHub: https://github.com/ShaleeQureshi