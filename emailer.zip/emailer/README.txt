This is an emailer program developed by Shahrukh Qureshi

-Add the jars in this folder to the build path (referenced libraries)
-In order for the user to send an email they must turn on "Allow less secure apps access" from their gmail settings or this will not work

Website: https://shaleequreshi2019.wixsite.com/website
GitHub: https://github.com/ShaleeQureshi