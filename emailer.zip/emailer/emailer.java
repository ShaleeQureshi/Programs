import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextPane;
import javax.swing.JTextField;

/*
Author: Shahrukh Qureshi
Date: April 6, 2020
Description: This program sends an email from a VALID email address to a VALID email address and gives the option to add an attachment\

Method List:
1. frameSetter(JFrame frame, int length, int width) = This method initializes each frame
2. introFrame(JFrame frame, JButton btn) = This method creates the first frame
3. emailUserFrame(JFrame frame, JButton btn, JButton btnExitProgram, JLabel lblEmail, JLabel lblPass, JTextField txtEmail, JPasswordField passwordField) = This method creates the second frame
4. emailMessageFrame(JFrame frame, JButton btn, JButton btnFile, JLabel lblRecp, JLabel lblSub, JLabel lblText, JTextPane txtPane, JTextField txtRecp, JTextField txtSub, JLabel lblAttachedFile) = This method creates the final frame
5. validationEmail(String email) = This method checks to see if the email address is valid or not prepareMessage(Session session, String email, String recipient, String subject, String text, String fileName) = This method prepares the message we send to the recipient
6. setProp(Properties prop) = This method sets the 4 properties that are essential to sending an email
7. sendMail(String recipient, String email, String password, String subject, String text, String fileName, JTextField txt) = This method sends the email
8. sendConfirmationEmail(String email, String password, String subject, String text, JTextField txt) = This method sends a confirmation email to the user if the message is sent

*/

public class emailer extends JFrame implements MouseListener, ActionListener {

    String frameTitle = "Emailer by Shahrukh Qureshi";

    JFrame frameIntro, frameEmailUser, frameEmailMessage, frameDone;

    JButton btnWelcome, btnContinue, btnSend, btnExit, btnAttachFile;

    JLabel lblUserID, lblUserPass, lblRecip, lblSubject, lblBody, lblFile, lblAttached;

    final JFileChooser fc;

    JTextField txtUserEmail, txtRecip, txtSub;

    JTextPane paneTxtBody;

    JPasswordField passUser;

    Cursor handCursor;

    int returnVal;

    public emailer() {

        // JFrames
        frameIntro = new JFrame(frameTitle);
        frameEmailUser = new JFrame(frameTitle);
        frameEmailMessage = new JFrame(frameTitle);
        frameDone = new JFrame(frameTitle);

        // Buttons
        btnWelcome = new JButton("Welcome to Emailer");
        btnContinue = new JButton("Continue");
        btnSend = new JButton("Send Email");
        btnExit = new JButton("Exit");
        btnAttachFile = new JButton("Attach File");

        // JLabels
        lblUserID = new JLabel("Enter your Email Address");
        lblUserPass = new JLabel("Enter your Email Password");
        lblRecip = new JLabel("Enter the recipient's email address:");
        lblSubject = new JLabel("<html><u>Subject<u><html>");
        lblBody = new JLabel("<html><u>Body<u><html>");
        lblAttached = new JLabel();

        // TextFields
        txtUserEmail = new JTextField();
        txtRecip = new JTextField();
        txtSub = new JTextField();

        // TextAreas
        paneTxtBody = new JTextPane();
        paneTxtBody.setEditable(true);

        // PasswordFields
        passUser = new JPasswordField();

        // FileChoser
        fc = new JFileChooser();

        // Fonts
        btnWelcome.setFont(new Font("Arial", Font.BOLD, 15));

        handCursor = new Cursor(Cursor.HAND_CURSOR);

        introFrame(frameIntro, btnWelcome);

    }// constructor

    // This method initializes each frame
    public void frameSetter(JFrame frame, int length, int width) {

        frame.getContentPane().setBackground(new Color(50, 197, 216)); // Changing the color of the Frame to a custom
                                                                       // color based off of RGB
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Setting its close operation
        frame.setSize(length, width); // Setting window size
        frame.setLayout(null); // Setting layout to null so we can decide the JComponents location
        frame.setLocationRelativeTo(null); // Setting the windows location to the center of the display
        frame.setResizable(false); // Making it so the user cannot resize the JFrame windows

    }// frameSetter Method

    // This method creates frameIntro
    public void introFrame(JFrame frame, JButton btn) {

        btn.setBackground(Color.GRAY);

        frameSetter(frame, 300, 200);

        btn.setBounds(50, 50, 200, 100);
        frame.add(btn);

        btn.addActionListener(this);
        btn.addMouseListener(this);
        btn.setCursor(handCursor);

        frame.setVisible(true);

    }// introFrame Method

    // This method creates frameEmailUser
    public void emailUserFrame(JFrame frame, JButton btn, JButton btnExitProgram, JLabel lblEmail, JLabel lblPass,
            JTextField txtEmail, JPasswordField passwordField) {

        btn.setBackground(Color.GRAY);
        btnExitProgram.setBackground(Color.GRAY);

        frameSetter(frame, 550, 260);

        lblEmail.setBounds(50, 50, 250, 50);
        frame.add(lblEmail);

        lblPass.setBounds(50, 120, 250, 50);
        frame.add(lblPass);

        txtEmail.setBounds(280, 50, 250, 50);
        frame.add(txtEmail);

        passwordField.setBounds(280, 120, 250, 50);
        frame.add(passwordField);

        btnExitProgram.setBounds(0, 180, 100, 50);
        frame.add(btnExitProgram);

        btn.setBounds(450, 180, 100, 50);
        frame.add(btn);

        btn.addActionListener(this);
        btnExitProgram.addActionListener(this);

        btn.addMouseListener(this);
        btnExitProgram.addMouseListener(this);

        btn.setCursor(handCursor);
        btnExitProgram.setCursor(handCursor);

        frame.setVisible(true);

    }// emailUserFrame Method

    // This method creates frameEmailMessage
    public void emailMessageFrame(JFrame frame, JButton btn, JButton btnFile, JLabel lblRecp, JLabel lblSub,
            JLabel lblText, JTextPane txtPane, JTextField txtRecp, JTextField txtSub, JLabel lblAttachedFile) {

        btn.setBackground(Color.GRAY);
        btnFile.setBackground(Color.GRAY);

        frameSetter(frame, 550, 700);

        lblRecp.setBounds(50, 50, 300, 50);
        frame.add(lblRecp);

        lblSub.setBounds(50, 120, 250, 50);
        frame.add(lblSub);

        lblText.setBounds(50, 220, 250, 50);
        frame.add(lblText);

        txtRecp.setBounds(320, 50, 200, 50);
        frame.add(txtRecp);

        txtSub.setBounds(50, 170, 300, 50);
        frame.add(txtSub);

        txtPane.setBounds(50, 260, 450, 300);
        frame.add(txtPane);

        btnFile.setBounds(50, 600, 150, 50);
        frame.add(btnFile);

        btn.setBounds(352, 600, 150, 50);
        frame.add(btn);

        lblAttachedFile.setBounds(50, 550, 300, 50);
        frame.add(lblAttachedFile);

        btnFile.addActionListener(this);
        btn.addActionListener(this);

        btnFile.addMouseListener(this);
        btn.addMouseListener(this);

        btnFile.setCursor(handCursor);
        btn.setCursor(handCursor);

        frame.setVisible(true);

    }// emailMessageFrame Method

    // This method verifies if an email is valid or not
    public static boolean validationEmail(String email) {

        // This api will give us much needed information regarding the email address
        String api = "http://apilayer.net/api/check?access_key=42fa3fe8d7f093c23d87a85cd43ecc6b&email=" + email
                + "&smtp=1&format=1";

        String inputString;

        StringBuffer buffer = new StringBuffer(); // StringBuffer used to append the information

        try {
            URL url = new URL(api); // Creating a URL object to read from the link to the api

            HttpURLConnection connection = (HttpURLConnection) url.openConnection(); // Creating a connection to the URL
                                                                                     // object

            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "chrome");

            // BufferedReader to read from the input stream
            BufferedReader input = new BufferedReader(new InputStreamReader(connection.getInputStream()));

            // While the contents are not null the following will occur
            while ((inputString = input.readLine()) != null) {
                buffer.append(inputString); // Appending the contents to create a sequence
            }
            input.close(); // Closing the BufferedReader

            String contents = buffer.toString(); // Converting the contents to a string

            // If the contents include the following we know the email address is valid
            if (contents.contains("\"smtp_check\":true") && contents.contains("\"mx_found\":true")) {
                return true;
            }
            // If not we know it is false
            else {
                return false;
            }

        } catch (Exception e) {
            return false; // Returning false if an exception occurs
        }

    }// validationEmail Method

    // This method prepares the message that we send to the recipient
    public static Message prepareMessage(Session session, String email, String recipient, String subject, String text,
            String fileName) {

        // Try-Catch block used in case an error occurs with the Message
        try {
            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress(email)); // Sender
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient)); // Recipient
            message.setSubject(subject); // Email subject

            // If the user wants to add an attachment then the following will occur
            if (!fileName.equalsIgnoreCase("No File")) {

                Multipart multipart = new MimeMultipart();
                BodyPart msgBodyPart = new MimeBodyPart();

                msgBodyPart.setText(text);
                multipart.addBodyPart(msgBodyPart);

                msgBodyPart = new MimeBodyPart(); // Email body

                DataSource source = new FileDataSource(fileName);
                msgBodyPart.setDataHandler(new DataHandler(source));
                msgBodyPart.setFileName(fileName);

                multipart.addBodyPart(msgBodyPart);

                message.setContent(multipart);
            }
            // If the user does not want to add an attachment then the following will occur
            else {
                message.setText(text); // Email body
            }

            return message; // Returing the prepared message

        }
        // If there is an error with the preperation of the message the following will
        // occur
        catch (Exception error) {
            JOptionPane.showMessageDialog(null, "An error has occured!");
        }
        return null; // Returing null if there is an error with the message

    }// prepareMessage Method

    // This method sets the 4 Properties needed to send an email
    public static Properties setProp(Properties prop) {

        prop.put("mail.smtp.auth", "true"); // Defines if an authentication is required by the email service
        prop.put("mail.smtp.starttls.enable", "true"); // For tls encryption (true for gmail)
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");

        return prop;

    }// setProp Method

    // This method sends the email to the recipient
    public static void sendMail(String recipient, String email, String password, String subject, String text,
            String fileName, JTextField txt) {

        Properties properties = new Properties();

        Message message;

        properties = setProp(properties); // Calling setProp method to set the properties required

        Session session = Session.getInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(email, password);
            }
        });
        // If the user does want to add an attachment
        if (!fileName.equalsIgnoreCase("No file")) {
            message = prepareMessage(session, email, recipient, subject, text, fileName);
        }
        // If the user does not want to add an attachment
        else {
            message = prepareMessage(session, email, recipient, subject, text, "No File");
        }

        try {
            Transport.send(message); // Sending the message (email)
            sendConfirmationEmail(email, password, subject, text, txt);
            JOptionPane.showMessageDialog(null,
                    "Email sent successfully!\nA Confirmation Email has been sent to " + email);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error has occured!");
        }
    }// sendMail Method

    // This method sends a confirmation email to the user when they send an email
    public static void sendConfirmationEmail(String email, String password, String subject, String text,
            JTextField txt) {

        Properties propertiesConfirmation = new Properties();

        propertiesConfirmation = setProp(propertiesConfirmation);

        Session session = Session.getInstance(propertiesConfirmation, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(email, password);
            }
        });

        Message messageConfirmation = prepareMessage(
                session, email, email, "Confirmation Email", "Hello " + email
                        + " this is a confirmation email. Your email to " + txt.getText() + " was successfully sent!",
                "No File");

        try {
            Transport.send(messageConfirmation);
        } catch (Exception error) {
            JOptionPane.showMessageDialog(null, "An error has occured");
        }

    }// sendConfirmationEmail Method

    public void actionPerformed(ActionEvent event) {

        boolean userEmailChecker = validationEmail(txtUserEmail.getText()); // To check the user's email
        boolean recipEmailChecker = validationEmail(txtRecip.getText()); // To check the recipient's email

        if (event.getSource() == btnWelcome) {
            frameIntro.dispose();
            emailUserFrame(frameEmailUser, btnContinue, btnExit, lblUserID, lblUserPass, txtUserEmail, passUser);
        } else if (event.getSource() == btnExit) {
            JOptionPane.showMessageDialog(null, "Thank you for using Emailer!");
            System.exit(0);
        } else if (event.getSource() == btnContinue && userEmailChecker == true) {

            frameEmailUser.dispose();
            emailMessageFrame(frameEmailMessage, btnSend, btnAttachFile, lblRecip, lblSubject, lblBody, paneTxtBody,
                    txtRecip, txtSub, lblAttached);
        } else if (event.getSource() == btnContinue && userEmailChecker != true) {
            JOptionPane.showMessageDialog(null, "Invalid Email Address");
        } else if (event.getSource() == btnAttachFile) {

            returnVal = fc.showOpenDialog(emailer.this);

            if (returnVal == JFileChooser.APPROVE_OPTION) {
                JOptionPane.showMessageDialog(null, fc.getSelectedFile().getName() + " has been attached!");
                lblAttached.setText(String.valueOf(fc.getSelectedFile().getName()));
            } else if (returnVal == JFileChooser.ERROR_OPTION) {
                JOptionPane.showMessageDialog(null, "An Error has occured");
            }
        } else if (event.getSource() == btnSend && recipEmailChecker == true && paneTxtBody.getText().length() != 0) {

            if (lblAttached.getText().length() > 0) {
                sendMail(txtRecip.getText(), txtUserEmail.getText(), String.valueOf(passUser.getPassword()),
                        txtSub.getText(), paneTxtBody.getText(), fc.getSelectedFile().getPath(), txtRecip);
            } else {
                sendMail(txtRecip.getText(), txtUserEmail.getText(), String.valueOf(passUser.getPassword()),
                        txtSub.getText(), paneTxtBody.getText(), "No File", txtRecip);
            }

        } else if (event.getSource() == btnSend && recipEmailChecker != true && paneTxtBody.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "Double check your entries!");
        }

    }// actionPerformed Method

    public void mouseClicked(MouseEvent arg0) {
    }

    public void mouseEntered(MouseEvent event) {
        if (event.getSource() == btnWelcome) {
            btnWelcome.setToolTipText("Click to send an email!");
        } else if (event.getSource() == btnContinue) {
            btnContinue.setToolTipText("Click to continue!");
        } else if (event.getSource() == btnAttachFile) {
            btnAttachFile.setToolTipText("Click to attach a file!");
        } else if (event.getSource() == btnSend) {
            btnSend.setToolTipText("Click to send your email!");
        } else if (event.getSource() == btnExit) {
            btnExit.setToolTipText("Click to exit!");
        }
    }

    public void mouseExited(MouseEvent arg0) {
    }

    public void mousePressed(MouseEvent arg0) {
    }

    public void mouseReleased(MouseEvent arg0) {
    }

    public static void main(String[] args) {

        new emailer();

    }// main Method

}// emailer Class