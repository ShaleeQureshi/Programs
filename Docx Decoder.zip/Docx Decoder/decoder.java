import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

/* 
* Author: Shahrukh Qureshi
* Date: March 13, 2020
* Description: Reads from a docx (Microsoft word) and txt (text) file.
*/

public class decoder {


    public static void errorMsg() {
        JOptionPane.showMessageDialog(null, "ERROR");
        System.exit(0);
    }//errorMessage Method
    
    //This method reads from a txt (text) file
    public static void readTxt(final String file) {

        try {
            final FileReader fileR = new FileReader(file); //Creating a file stream
            final BufferedReader readFile = new BufferedReader(fileR); //A method to read from the filestream

            String line = "";
            //As long as the lines in the file are not empty their info will be stored onto the "line" variable and outputted
            while ((line = readFile.readLine()) != null) {
                System.out.println(line);
            }
            fileR.close(); //Closing the file stream
            readFile.close(); //Closing the file stream

        } catch (final IOException error) {
            errorMsg(); //Calling the errorMsg Method in the event of an error
        }

    }// readTxt Method

    //This method reads from a docx (Microsoft Word File)
    public static void readDocx(final String file) {

        try {
            final FileInputStream fileS = new FileInputStream(file); //Creating a stream to the file
            final XWPFDocument document = new XWPFDocument(fileS); //Method of reading the XML from the file

            XWPFWordExtractor text = new XWPFWordExtractor(document); //Getting the info from the file (converts from XML to Binary)
            
            System.out.println(text.getText()); //Outputting it

        } catch (final IOException error) {
            errorMsg(); //Calling the errorMsg Method in the event of an error

        }

    }//readDocx Method

    //Main Method
    public static void main(final String[] args) {

        //Prompting user for file type
        String fileType = JOptionPane.showInputDialog(null, "Enter the file type (docx or txt)");

        //If the user enters txt then the following will occur
        if (fileType.equalsIgnoreCase("txt")) {
            String fileRead = JOptionPane.showInputDialog(null, "Enter file"); //Prompting for file
            readTxt(fileRead); //Calling readTxt method to read from the txt file
        }
        else {
            String fileRead = JOptionPane.showInputDialog(null, "Enter file"); //Prompting for file
            readDocx(fileRead); //Calling readDocx method to read from the docx file
        }

    }//main Method
    
}//Class decoder