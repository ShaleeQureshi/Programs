import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/*
Author: Shalee Qureshi 
Date: March 31, 2020
Description: This class contains all of the methods that allows the functions for the basic calculator to operate

Method List:

1. whenOperationsUsed(JTextArea a, JLabel b) = This method fixes the issue between putting the info from the textarea to the label
2. setText(JTextArea a, String num) = This method sets the display text
3. returnType(double answer) = This method checks to see if there is a decimal in the answer (to return double or long based on it)
4. fixAnswer(double answer, JTextArea a) = This method fixes the final answer 
5. fixSign(String num) = This method fixes the sign of the strings (num- to -num)
6. double sum(double num1, double num2) = This method adds two values
7. double subtract (double num1, double num2) = This method subtracts two values
8. divide(double num1, double num2) = This method divides two values
9. multiply(double num1, double num2) = This method multiples two values
10. square (double num) = This method squares a number 
11. squareRoot (double num) = This method square roots a number
12. trigFunctions (double num, String typeOfFunction) = This method performs a trig function based on the one the user selected
13. raiseToPowerOf (double num1, double num2) = Raises num1 to the power of num2
14. xRootY (double num1, double num2) = Finds the root of a number
*/

public class scientificCalcBackEnd {

    static String oldStringValue;

    // This method fixes the issue between putting the info from the textarea to the
    // label
    public static void whenOperationsUsed(JTextArea a, JLabel b) {

        if (a.getText().contains("-")) {
            b.setText("-" + a.getText().replaceAll("-", ""));
        } else {
            b.setText(a.getText());
        }
        a.setText("0");

    }// whenOperationsUsed Method

    // This method sets the display text
    public static void setText(JTextArea a, String num) {

        if (a.getText().contains("0") && a.getText().length() == 1) {
            a.setText(num);
        } else {
            if (a.getText().contains("-")) {
                a.setText((a.getText() + num).replaceAll("-", "") + "-");
            } else {
                a.setText(a.getText() + num);
            }
        }

    }// setText Method

    // This method checks to see if there is a decimal in the answer (to return
    // double or long based on it)
    public static long returnType(double answer) {

        if (Math.round(answer) == answer) {
            return Math.round(answer);
        }

        return 1;

    }// returnType

    // This method fixes the final answer
    public static void fixAnswer(double answer, JTextArea a) {

        long type = returnType(answer);

        String lblMsg = "Your answer is:\n";
        JLabel lblMessage = new JLabel (); //Object for JOptionPane.showMessageDialog
        lblMessage.setFont(new Font ("Arial", Font.PLAIN, 20)); //Settings its font

        if (type != 1) {
            if (Double.toString(answer).length() > 9) {
                a.setText("0");    
                lblMessage.setText(lblMsg + Math.round(answer));
                JOptionPane.showMessageDialog(null, lblMessage, "Scientific Calculator by Shahrukh Qureshi", 1);
            } else {
                if (answer > 0) {
                    a.setText("" + Math.round(answer));
                } else {
                    a.setText(Math.abs(answer) + "-");
                }
            }

        } else {
            if (Double.toString(answer).length() > 9) {
                a.setText("0");
                lblMessage.setText(lblMsg + answer);
                JOptionPane.showMessageDialog(null, lblMessage,"Scientific Calculator by Shahrukh Qureshi", 1);
            } else {
                if (answer > 0) {
                    a.setText("" + answer);
                } else {
                    a.setText(Math.abs(answer) + "-");
                }
            }
        }

    }// fixAnswer Method

    // This method fixes the sign of the strings (num- to -num)
    public static String fixSign(String num) {

        if (num.contains("-")) {
            return "-" + num.replaceAll("-", "");
        } else {
            return num;
        }

    }// fixSign Method

    // This method adds two values
    public static double sum(double num1, double num2) {
        return num1 + num2;
    }// sum Method

    // This method subtracts two values
    public static double subtract(double num1, double num2) {
        return num1 - num2;
    }// subtract Method

    // This method divides two values
    public static double divide(double num1, double num2) {
        return num1 / num2;
    }// divide Method

    // This method multiplies two values
    public static double multiply(double num1, double num2) {
        return num1 * num2;
    }// multiply Method

    //This method squares a number
    public static double square (double num){
        return Math.pow(num, 2);
    }//square Method

    //This method square roots a number
    public static double squareRoot (double num){
        return Math.sqrt(num);
    }//squareRoot Method

    //This method performs a trig function based on the one the user selected
    public static double trigFunctions (double num, String typeOfFunction) {
        if (typeOfFunction.equals("SIN")){
            return Math.sin(Math.toRadians(num));
        }
        else if (typeOfFunction.equals("COS")){
            return Math.cos(Math.toRadians(num));
        }
        else if (typeOfFunction.equals("TAN")){
            return Math.tan(Math.toRadians(num));
        }
        else if (typeOfFunction.equals("SIN-1")){
            return Math.toDegrees(Math.asin(num));
        }
        else if (typeOfFunction.equals("COS-1")){
            return Math.toDegrees(Math.acos(num));
        }
        else {
            return Math.toDegrees(Math.atan(num));
        }
        
    }//trigFunctions Method

    //This method raises a number to the power of a user inputted value
    public static double raiseToPowerOf (double num1, double num2){
        return Math.pow(num1, num2);
    }//raiseToPowerOf Method

    //This method finds the root of a number
    public static double xRootY (double num1, double num2){
        return Math.pow(num1, 1.0 / num2 );
    }//xRootY Method

    //This method converts the number to 1/number
    public static double OneOverX (double num){
        return 1.0 / num;
    }//OneOverX Method

}// class simpleCalcBackEnd