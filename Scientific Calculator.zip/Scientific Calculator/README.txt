This is a scientific calculator developed by Shahrukh Qureshi
-Run this program through the scientificCalc.java file

Website: https://shaleequreshi2019.wixsite.com/website
GitHub: https://github.com/ShaleeQureshi