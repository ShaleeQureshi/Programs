import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Font;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import javax.swing.JOptionPane;

/* 
Author: Shalee Qureshi 
Date: March 31, 2020
Description: A basic calculator with the 4 basic operations (addition, subtraction, multiplication, division) and the option for plus/minus

Method List:

1. actionPerformed(ActionEvent e) = Performs a task when an action is invoked
2. mouseClicked(MouseEvent e) = Not used in this program
3. mousePressed(MouseEvent e) = Not used in this program
4. mouseReleased(MouseEvent e) = Not used in this program
5. mouseEntered(MouseEvent e) = Not used in this program
6. mouseExited(MouseEvent e) = Not used in this program

*/

public class scientificCalc extends JFrame implements ActionListener, MouseListener {

    // Declaring global variables

    JLabel lblAuthor, lblBeforeOperation;

    static JTextArea lblResult;

    JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0, btnClear, btnEqual, btnSubtract, btnAdd,
            btnDivide, btnMultiply, btnDot, btnPlusMinus, btnSquareNum, btnSquareRoot, btnPie, btnSin, btnCos, btnTan, btnToThePowerOf, btnXRootY, btn1OverX, btnSecond;

    Font fontBtn, fontTrigInverse;

    LineBorder border;

    Cursor handCursor;

    String operation;

    int inverse;

    public scientificCalc() {

        // Initializing labels
        lblAuthor = new JLabel("Developed by Shahrukh Qureshi");
        lblBeforeOperation = new JLabel();

        // Initializing JTextArea
        lblResult = new JTextArea();

        // Initializing buttons
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        btn6 = new JButton("6");
        btn7 = new JButton("7");
        btn8 = new JButton("8");
        btn9 = new JButton("9");
        btn0 = new JButton("0");
        btnClear = new JButton("C");
        btnEqual = new JButton("=");
        btnSubtract = new JButton("-");
        btnAdd = new JButton("+");
        btnDivide = new JButton("÷");
        btnMultiply = new JButton("x");
        btnDot = new JButton(".");
        btnPlusMinus = new JButton("+/-");
        btnSquareNum = new JButton ("<html>x<sup>2</sup></html>");
        btnSquareRoot = new JButton("<html>&#8730;</html>");
        btnPie = new JButton ("<html>&pi;</html>");
        btnSin = new JButton("SIN");
        btnCos = new JButton("COS");
        btnTan = new JButton ("TAN");
        btnToThePowerOf = new JButton("<html>y<sup>x</sup></html>");
        btnXRootY = new JButton ("<html>x<sup>&#8730;</sup></html>");
        btnXRootY = new JButton("<html>x&#8730;y</html>");
        btn1OverX = new JButton("1/x");
        btnSecond = new JButton("2nd");

        // Fonts
        fontBtn = new Font("Arial", Font.BOLD, 15);

        // Cursor
        handCursor = new Cursor(Cursor.HAND_CURSOR);

        // Adding font to buttons
        btn1.setFont(fontBtn);
        btn2.setFont(fontBtn);
        btn3.setFont(fontBtn);
        btn4.setFont(fontBtn);
        btn5.setFont(fontBtn);
        btn6.setFont(fontBtn);
        btn7.setFont(fontBtn);
        btn8.setFont(fontBtn);
        btn9.setFont(fontBtn);
        btn0.setFont(fontBtn);
        btnClear.setFont(fontBtn);
        btnEqual.setFont(fontBtn);
        btnSubtract.setFont(fontBtn);
        btnAdd.setFont(fontBtn);
        btnDivide.setFont(fontBtn);
        btnMultiply.setFont(fontBtn);
        btnDot.setFont(fontBtn);
        btnPlusMinus.setFont(fontBtn);
        btnSin.setFont(new Font("Arial", Font.BOLD, 8));
        btnCos.setFont(new Font("Arial", Font.BOLD, 7));
        btnTan.setFont(new Font("Arial", Font.BOLD, 7));
        btnPlusMinus.setFont(new Font("Arial", Font.BOLD, 10));
        lblAuthor.setFont(new Font("Arial", Font.PLAIN, 8));
        lblResult.setFont(new Font("Arial", Font.BOLD, 45));
        btn1OverX.setFont(new Font ("Arial", Font.BOLD, 9));
        btnSecond.setFont(new Font ("Arial", Font.BOLD, 7));

        // Adding border
        border = new LineBorder(Color.BLACK);

        // Adding the border to the lbl
        lblResult.setBorder(border);

        // Setting JComponents (x, y, width, height) and adding them
        lblResult.setBounds(40, 15, 300, 50);
        lblResult.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        lblResult.setEditable(false);
        lblResult.setOpaque(false);
        lblResult.setText("0");
        add(lblResult);

        lblAuthor.setBounds(220, 360, 150, 100);
        add(lblAuthor);

        lblBeforeOperation.setBounds(40, 0, 300, 50);
        add(lblBeforeOperation);

        btn7.setBounds(40, 190, 50, 50);
        add(btn7);

        btn8.setBounds(100, 190, 50, 50);
        add(btn8);

        btn9.setBounds(160, 190, 50, 50);
        add(btn9);

        btn4.setBounds(40, 250, 50, 50);
        add(btn4);

        btn5.setBounds(100, 250, 50, 50);
        add(btn5);

        btn6.setBounds(160, 250, 50, 50);
        add(btn6);

        btn1.setBounds(40, 310, 50, 50);
        add(btn1);

        btn2.setBounds(100, 310, 50, 50);
        add(btn2);

        btn3.setBounds(160, 310, 50, 50);
        add(btn3);

        btnClear.setBounds(40, 370, 50, 50);
        add(btnClear);
        btnClear.setBackground(Color.RED);

        btn0.setBounds(100, 370, 50, 50);
        add(btn0);

        btnDot.setBounds(160, 370, 50, 50);
        add(btnDot);

        // Operations

        btnMultiply.setBounds(220, 190, 50, 50);
        btnMultiply.setBackground(Color.GRAY);
        add(btnMultiply);

        btnDivide.setBounds(280, 190, 50, 50);
        btnDivide.setBackground(Color.GRAY);
        add(btnDivide);

        btnSubtract.setBounds(220, 250, 50, 50);
        btnSubtract.setBackground(Color.GRAY);
        add(btnSubtract);

        btnAdd.setBounds(280, 250, 50, 50);
        btnAdd.setBackground(Color.GRAY);
        add(btnAdd);

        btnPlusMinus.setBounds(220, 310, 50, 50);
        btnPlusMinus.setBackground(Color.GRAY);
        add(btnPlusMinus);

        btnEqual.setBounds(280, 310, 50, 50);
        btnEqual.setBackground(new Color(66, 191, 245));
        add(btnEqual);

        btnSquareNum.setBounds(40, 130, 50, 50);
        btnSquareNum.setBackground(Color.GRAY);
        add(btnSquareNum);

        btnSquareRoot.setBounds(100, 130, 50, 50);
        btnSquareRoot.setBackground(Color.GRAY);
        add(btnSquareRoot);

        btnPie.setBounds(40, 70, 50, 50);
        btnPie.setBackground(Color.GRAY);
        add(btnPie);
        
        btnSin.setBounds(100, 70, 50, 50);
        btnSin.setBackground(Color.GRAY);
        add(btnSin);

        btnCos.setBounds(160, 70, 50, 50);
        btnCos.setBackground(Color.GRAY);
        add(btnCos);

        btnTan.setBounds(220, 70, 50, 50);
        btnTan.setBackground(Color.GRAY);
        add(btnTan);

        btnToThePowerOf.setBounds(160, 130, 50, 50);
        btnToThePowerOf.setBackground(Color.GRAY);
        add(btnToThePowerOf);

        btnXRootY.setBounds(220, 130, 50, 50);
        btnXRootY.setBackground(Color.GRAY);
        add(btnXRootY);

        btn1OverX.setBounds(280, 130, 50, 50);
        btn1OverX.setBackground(Color.GRAY);
        add(btn1OverX);

        btnSecond.setBounds(280, 70, 50, 50);
        btnSecond.setBackground(Color.GRAY);
        add(btnSecond);

        // Adding listeners/cursor to buttons
        btn0.addActionListener(this);
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        btn5.addActionListener(this);
        btn6.addActionListener(this);
        btn7.addActionListener(this);
        btn8.addActionListener(this);
        btn9.addActionListener(this);
        btnAdd.addActionListener(this);
        btnSubtract.addActionListener(this);
        btnPlusMinus.addActionListener(this);
        btnDivide.addActionListener(this);
        btnMultiply.addActionListener(this);
        btnEqual.addActionListener(this);
        btnClear.addActionListener(this);
        btnDot.addActionListener(this);
        btnSquareNum.addActionListener(this);
        btnSquareRoot.addActionListener(this);
        btnPie.addActionListener(this);
        btnSin.addActionListener(this);
        btnCos.addActionListener(this);
        btnTan.addActionListener(this);
        btnToThePowerOf.addActionListener(this);
        btnXRootY.addActionListener(this);
        btn1OverX.addActionListener(this);
        btnSecond.addActionListener(this);
        

        btn0.addMouseListener(this);
        btn1.addMouseListener(this);
        btn2.addMouseListener(this);
        btn3.addMouseListener(this);
        btn4.addMouseListener(this);
        btn5.addMouseListener(this);
        btn6.addMouseListener(this);
        btn7.addMouseListener(this);
        btn8.addMouseListener(this);
        btn9.addMouseListener(this);
        btn0.addMouseListener(this);
        btnAdd.addMouseListener(this);
        btnSubtract.addMouseListener(this);
        btnPlusMinus.addMouseListener(this);
        btnDivide.addMouseListener(this);
        btnMultiply.addMouseListener(this);
        btnEqual.addMouseListener(this);
        btnClear.addMouseListener(this);
        btnDot.addMouseListener(this);
        btnSquareNum.addMouseListener(this);
        btnSquareRoot.addMouseListener(this);
        btnPie.addMouseListener(this);
        btnSin.addMouseListener(this);
        btnCos.addMouseListener(this);
        btnTan.addMouseListener(this);
        btnToThePowerOf.addMouseListener(this);
        btnXRootY.addMouseListener(this);
        btn1OverX.addMouseListener(this);
        btnSecond.addMouseListener(this);


        btn0.setCursor(handCursor);
        btn1.setCursor(handCursor);
        btn2.setCursor(handCursor);
        btn3.setCursor(handCursor);
        btn4.setCursor(handCursor);
        btn5.setCursor(handCursor);
        btn6.setCursor(handCursor);
        btn7.setCursor(handCursor);
        btn8.setCursor(handCursor);
        btn9.setCursor(handCursor);
        btn0.setCursor(handCursor);
        btnAdd.setCursor(handCursor);
        btnSubtract.setCursor(handCursor);
        btnPlusMinus.setCursor(handCursor);
        btnDivide.setCursor(handCursor);
        btnMultiply.setCursor(handCursor);
        btnEqual.setCursor(handCursor);
        btnClear.setCursor(handCursor);
        btnDot.setCursor(handCursor);
        btnSquareNum.setCursor(handCursor);
        btnSquareRoot.setCursor(handCursor);
        btnPie.setCursor(handCursor);
        btnSin.setCursor(handCursor);
        btnCos.setCursor(handCursor);
        btnTan.setCursor(handCursor);
        btnToThePowerOf.setCursor(handCursor);
        btnXRootY.setCursor(handCursor);
        btn1OverX.setCursor(handCursor);
        btnSecond.setCursor(handCursor);


        setSize(390, 480);
        setLocationRelativeTo(null);
        setTitle("Scientific Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(null);

        setVisible(true);

    }// constructor

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btn1) {

            scientificCalcBackEnd.setText(lblResult, "1");

        } else if (e.getSource() == btn2) {

            scientificCalcBackEnd.setText(lblResult, "2");

        } else if (e.getSource() == btn3) {

            scientificCalcBackEnd.setText(lblResult, "3");

        } else if (e.getSource() == btn4) {

            scientificCalcBackEnd.setText(lblResult, "4");

        } else if (e.getSource() == btn5) {

            scientificCalcBackEnd.setText(lblResult, "5");

        } else if (e.getSource() == btn6) {

            scientificCalcBackEnd.setText(lblResult, "6");

        } else if (e.getSource() == btn7) {

            scientificCalcBackEnd.setText(lblResult, "7");

        } else if (e.getSource() == btn8) {

            scientificCalcBackEnd.setText(lblResult, "8");

        } else if (e.getSource() == btn9) {

            scientificCalcBackEnd.setText(lblResult, "9");

        } else if (e.getSource() == btn0 && lblResult.getText().length() != 0) {

            scientificCalcBackEnd.setText(lblResult, "0");

        } else if (e.getSource() == btnClear) {

            lblBeforeOperation.setText("");
            lblResult.setText("0");
            
            if (btnSin.getText() != "SIN"){
                btnSin.setText("SIN");
                btnCos.setText("COS");
                btnTan.setText("TAN");
                inverse = 0;
            }

        } else if (e.getSource() == btnDot && !lblResult.getText().contains(".")) {

            lblResult.setText(lblResult.getText() + ".");

        } else if (e.getSource() == btnAdd) {

            scientificCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "add";

        } else if (e.getSource() == btnSubtract) {

            scientificCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "subtract";

        } else if (e.getSource() == btnDivide) {

            scientificCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "divide";

        } else if (e.getSource() == btnMultiply) {

            scientificCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);

            operation = "multiply";

        } else if (e.getSource() == btnPlusMinus) {

            if (!lblResult.getText().contains("-")) {
                lblResult.setText(lblResult.getText() + "-");
            } else {
                lblResult.setText(lblResult.getText().replaceAll("-", ""));
            }

        }
        else if (e.getSource() == btnSquareNum){
            double squaredNum = scientificCalcBackEnd.square(Double.parseDouble(lblResult.getText().replaceAll("-", "")));
            scientificCalcBackEnd.fixAnswer(squaredNum, lblResult);
        }
        else if (e.getSource() == btnSquareRoot){
            if (lblResult.getText().contains("-")){
                JOptionPane.showMessageDialog(null, "ERROR");
                dispose();
                new scientificCalc();
            }
            else {
                double squareRootedNum = scientificCalcBackEnd.squareRoot(Double.parseDouble(lblResult.getText()));
                scientificCalcBackEnd.fixAnswer(squareRootedNum, lblResult);
            }
        }
        else if (e.getSource() == btnPie){
            lblResult.setText("" + Math.PI);
        }
        else if (e.getSource() == btnSin){
            lblBeforeOperation.setText(lblResult.getText());
            if (inverse != 1){
                scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.trigFunctions(Double.parseDouble(lblBeforeOperation.getText()), "SIN"), lblResult);
            }
            else {
                scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.trigFunctions(Double.parseDouble(lblBeforeOperation.getText()), "SIN-1"), lblResult);
            }
            lblBeforeOperation.setText("");
        }
        else if (e.getSource() == btnCos){
            lblBeforeOperation.setText(lblResult.getText());
            if (inverse != 1){
                scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.trigFunctions(Double.parseDouble(lblBeforeOperation.getText()), "COS"), lblResult);
            }
            else {
                scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.trigFunctions(Double.parseDouble(lblBeforeOperation.getText()), "COS-1"), lblResult);
            }
            lblBeforeOperation.setText("");
        }
        else if (e.getSource() == btnTan){
            lblBeforeOperation.setText(lblResult.getText());
            if (inverse != 1){
                scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.trigFunctions(Double.parseDouble(lblBeforeOperation.getText()), "TAN"), lblResult);
            }
            else {
                scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.trigFunctions(Double.parseDouble(lblBeforeOperation.getText()), "TAN-1"), lblResult);
            }
            lblBeforeOperation.setText("");
        }
        else if (e.getSource() == btnToThePowerOf){
            scientificCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);
            operation = "yToX";
        }
        else if (e.getSource() == btnXRootY){
            scientificCalcBackEnd.whenOperationsUsed(lblResult, lblBeforeOperation);
            operation = "yRootX";
        }
        else if (e.getSource() == btn1OverX){
            scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.OneOverX(Double.parseDouble(lblResult.getText())), lblResult);
        }
        else if (e.getSource() == btnSecond){

            btnSin.setText("<html>SIN<sup>-1</sup></html>");
            btnCos.setText("<html>COS<sup>-1</sup></html>");
            btnTan.setText("<html>TAN<sup>-1</sup></html>");

            inverse = 1;

        }
        else if (e.getSource() == btnEqual) {

            double answer;
            String beforeSignFixed;

            try {
                if (operation.equals("add")) {

                    beforeSignFixed = scientificCalcBackEnd.fixSign(lblResult.getText());

                    answer = scientificCalcBackEnd.sum(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    scientificCalcBackEnd.fixAnswer(answer, lblResult);

                } else if (operation.equals("subtract")) {

                    beforeSignFixed = scientificCalcBackEnd.fixSign(lblResult.getText());

                    answer = scientificCalcBackEnd.subtract(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    scientificCalcBackEnd.fixAnswer(answer, lblResult);

                } else if (operation.equals("divide")) {

                    beforeSignFixed = scientificCalcBackEnd.fixSign(lblResult.getText());

                    answer = scientificCalcBackEnd.divide(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    scientificCalcBackEnd.fixAnswer(answer, lblResult);

                } else if (operation.equals("multiply")) {

                    beforeSignFixed = scientificCalcBackEnd.fixSign(lblResult.getText());

                    answer = scientificCalcBackEnd.multiply(Double.parseDouble(lblBeforeOperation.getText()),
                            Double.parseDouble(beforeSignFixed));
                    lblBeforeOperation.setText("");

                    scientificCalcBackEnd.fixAnswer(answer, lblResult);

                }
                else if (operation.equals("yToX")){
                    scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.raiseToPowerOf(Double.parseDouble(lblBeforeOperation.getText()), Double.parseDouble(lblResult.getText())), lblResult);
                    lblBeforeOperation.setText("");
                }
                else if (operation.equals("yRootX")){
                scientificCalcBackEnd.fixAnswer(scientificCalcBackEnd.xRootY(Double.parseDouble(lblBeforeOperation.getText()), Double.parseDouble(lblResult.getText())), lblResult);
                lblBeforeOperation.setText("");    
                }
            } catch (Exception error) {
                dispose();
                JOptionPane.showMessageDialog(null, "An Unexpected Error has occured.\nThe Program will now restart.");
                new scientificCalc();
            }
            
        }

    }// actionPerformed Method

    public void mouseClicked(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public static void main(String[] args) {

        new scientificCalc();

    }// main Method

}// class simpleCalc