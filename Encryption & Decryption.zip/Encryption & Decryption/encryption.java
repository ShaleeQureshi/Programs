import java.awt.Color;
import java.awt.Font;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.plaf.basic.BasicArrowButton;

/* 
Author: Shalee Qureshi 
Date: April 9, 2020
Description: A GUI that gives the user the option to encrypt and decrypt data and saves it to a specified file.

Method List:

1. frameSetter(JFrame frame, int length, int width) = This method initializes each frame
2. welcomeFrame(JFrame frame, JButton btn) = This method creates the first frame
3. menuFrame(JFrame frame, JButton btnEnc, JButton btnDec, JButton btnInfo) = This method creates the second frame
4. encFrame(JFrame frame, JTextPane paneTxt, JButton btnSelect, JButton btnEnc, JLabel lblTitle, JLabel lblOr, JLabel lblOtherOption, JLabel lblFile, BasicArrowButton basicBtn)  = This method creates the encryption frame
5. decFrame(JFrame frame, JButton btnSelect, JButton btnDec, JLabel lblFile, JLabel lblImportedFile, BasicArrowButton basicBtn) = This method creates the decryption frame
6. aboutFrame(JFrame frame, JLabel lblCreator, JLabel lblLink, BasicArrowButton backBasicArrowButton, JLabel lblTitle) = This method creates the AboutFrame
7. encrypter(byte data[]) = This method encryptes the data depending on if the index values are even or odd (ASCII)
8. decrypter(byte data[]) = This method encryptes the data depending on if the index values are even or odd (ASCII)
9. readFile(String filePath) = This method will read from the selected file and store it as a byte array
10. fileOutput(byte[] data, String encOrDec) = This method will save the encrypted data to a file
11. There are also the implmented methods included in ActionListener and MouseListener
*/
public class encryption extends JFrame implements ActionListener, MouseListener {

    String frameTitle = "SecureData by Shahrukh Qureshi";

    JFrame frameWelcome, frameMenu, frameEncrypt, frameDecrypt, frameAbout;

    JButton btnWelcome, btnEncrypt, btnDecrypt, btnSelectFile, btnSecure, btnUnsecure, btnAbout;

    BasicArrowButton basicBtn;

    JTextPane paneTxtEnc;

    JFileChooser fChooser;

    JLabel lblEnc, lblOr, lblSelectFile, lblSelectedFile, lblDec, lblAuthor, lblGitHub, lblAboutTitle;

    Cursor handCursor;

    Font font;

    // This is a void constructor
    public encryption() {

        // JFrames
        frameWelcome = new JFrame(frameTitle);
        frameMenu = new JFrame(frameTitle);
        frameEncrypt = new JFrame(frameTitle);
        frameDecrypt = new JFrame(frameTitle);
        frameAbout = new JFrame(frameTitle);

        // Buttons
        btnWelcome = new JButton("Welcome to SecureData");
        btnEncrypt = new JButton("Encrypt Data");
        btnDecrypt = new JButton("Decrypt Data");
        btnSelectFile = new JButton("Select File");
        btnSecure = new JButton("Secure");
        btnUnsecure = new JButton("UnSecure");
        basicBtn = new BasicArrowButton(BasicArrowButton.WEST);
        btnAbout = new JButton("About");

        // JTextPane
        paneTxtEnc = new JTextPane();

        // JFileChooser
        fChooser = new JFileChooser();

        // JLabels
        lblEnc = new JLabel("<html><u>Enter the information you wish to secure<u><html>");
        lblOr = new JLabel("Or");
        lblSelectFile = new JLabel("<html><u>Import a file<u><html>");
        lblSelectedFile = new JLabel();
        lblDec = new JLabel("<html><u>Import the file you wish to unsecure<u><html>");
        lblAuthor = new JLabel("This program was developed by Shahrukh Qureshi");
        lblGitHub = new JLabel("Click to view my GitHub");
        lblAboutTitle = new JLabel("<html><u>SecureData's Developer<u><html>");

        // Fonts
        font = new Font("Arial", Font.BOLD, 15);

        // Cursor
        handCursor = new Cursor(Cursor.HAND_CURSOR);

        welcomeFrame(frameWelcome, btnWelcome);

    }// constructor

    // This method initializes each frame
    public void frameSetter(JFrame frame, int length, int width) {

        frame.getContentPane().setBackground(new Color(50, 197, 216)); // Changing the color of the Frame to a custom
                                                                       // color based off of RGB
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Setting its close operation
        frame.setSize(length, width); // Setting window size
        frame.setLayout(null); // Setting layout to null so we can decide the JComponents location
        frame.setLocationRelativeTo(null); // Setting the windows location to the center of the display
        frame.setResizable(false); // Making it so the user cannot resize the JFrame windows

    }// frameSetter Method

    // This method creates the first frame
    public void welcomeFrame(JFrame frame, JButton btn) {

        frameSetter(frame, 300, 200);

        btn.setBackground(Color.GRAY);

        btn.setBounds(25, 50, 250, 75);
        frame.add(btn);

        btn.setCursor(handCursor);
        btn.setFont(font);

        btn.addActionListener(this);
        btn.addMouseListener(this);

        frame.setVisible(true);

    }// welcomeFrame Method

    // This method creates the second frame
    public void menuFrame(JFrame frame, JButton btnEnc, JButton btnDec, JButton btnInfo) {

        frameSetter(frame, 250, 300);

        btnDec.setBackground(Color.GRAY);
        btnEnc.setBackground(Color.GRAY);
        btnInfo.setBackground(Color.GRAY);

        btnDec.setFont(font);
        btnEnc.setFont(font);

        btnDec.setCursor(handCursor);
        btnEnc.setCursor(handCursor);
        btnInfo.setCursor(handCursor);

        btnEnc.setBounds(50, 40, 150, 75);
        frame.add(btnEnc);

        btnDec.setBounds(50, 140, 150, 75);
        frame.add(btnDec);

        btnInfo.setBounds(170, 225, 80, 50);
        frame.add(btnInfo);

        btnEnc.addActionListener(this);
        btnDec.addActionListener(this);
        btnInfo.addActionListener(this);

        btnEnc.addMouseListener(this);
        btnDec.addMouseListener(this);
        btnInfo.addMouseListener(this);

        frame.setVisible(true);

    }// menuFrame

    // This method creates the encryption frame
    public void encFrame(JFrame frame, JTextPane paneTxt, JButton btnSelect, JButton btnEnc, JLabel lblTitle,
            JLabel lblOr, JLabel lblOtherOption, JLabel lblFile, BasicArrowButton basicBtn) {

        frameSetter(frame, 500, 600);

        btnSelect.setBackground(Color.GRAY);
        btnEnc.setBackground(Color.GRAY);

        lblTitle.setFont(font);
        lblOr.setFont(font);
        lblOtherOption.setFont(font);

        lblTitle.setBounds(75, 50, 400, 50);
        frame.add(lblTitle);

        lblOr.setBounds(240, 100, 100, 50);
        frame.add(lblOr);

        lblOtherOption.setBounds(200, 150, 200, 50);
        frame.add(lblOtherOption);

        paneTxt.setBounds(75, 200, 345, 250);
        paneTxt.setEditable(true);
        frame.add(paneTxt);

        lblFile.setBounds(75, 440, 300, 50);
        frame.add(lblFile);

        btnEnc.setBounds(322, 490, 100, 50);
        frame.add(btnEnc);

        btnSelect.setBounds(75, 490, 150, 50);
        frame.add(btnSelect);

        basicBtn.setBounds(0, 0, 50, 50);
        frame.add(basicBtn);

        btnEnc.addActionListener(this);
        btnSelect.addActionListener(this);
        basicBtn.addActionListener(this);

        btnEnc.addMouseListener(this);
        btnSelect.addMouseListener(this);
        basicBtn.addMouseListener(this);

        btnEnc.setCursor(handCursor);
        btnSelect.setCursor(handCursor);
        basicBtn.setCursor(handCursor);

        frame.setVisible(true);

    }// encFrame Method

    // This method creates the decryption frame
    public void decFrame(JFrame frame, JButton btnSelect, JButton btnDec, JLabel lblFile, JLabel lblImportedFile,
            BasicArrowButton basicBtn) {
        frameSetter(frame, 500, 250);

        btnSelect.setBackground(Color.GRAY);
        btnDec.setBackground(Color.GRAY);

        lblFile.setFont(new Font("Arial", Font.BOLD, 15));

        lblFile.setBounds(75, 40, 300, 50);
        frame.add(lblFile);

        btnDec.setBounds(315, 140, 107, 50);
        frame.add(btnDec);

        btnSelect.setBounds(75, 140, 150, 50);
        frame.add(btnSelect);

        lblImportedFile.setBounds(75, 90, 300, 50);
        frame.add(lblImportedFile);

        basicBtn.setBounds(0, 0, 50, 50);
        frame.add(basicBtn);

        btnDec.addActionListener(this);
        btnSelect.addActionListener(this);
        basicBtn.addActionListener(this);

        btnDec.addMouseListener(this);
        btnSelect.addMouseListener(this);
        basicBtn.addMouseListener(this);

        btnDec.setCursor(handCursor);
        btnSelect.setCursor(handCursor);
        basicBtn.setCursor(handCursor);

        frame.setVisible(true);

    } // decFrame Method

    // This method creates the AboutFrame
    public void aboutFrame(JFrame frame, JLabel lblCreator, JLabel lblLink, BasicArrowButton backBasicArrowButton,
            JLabel lblTitle) {

        frameSetter(frame, 400, 200);

        lblLink.setForeground(Color.BLUE);

        lblTitle.setFont(font);

        lblTitle.setBounds(100, 15, 200, 50);
        frame.add(lblTitle);

        lblCreator.setBounds(25, 50, 400, 50);
        frame.add(lblCreator);

        lblLink.setBounds(25, 110, 200, 50);
        frame.add(lblLink);

        backBasicArrowButton.setBounds(0, 0, 50, 50);
        frame.add(backBasicArrowButton);

        lblLink.addMouseListener(this);
        lblLink.setCursor(handCursor);

        backBasicArrowButton.addActionListener(this);
        backBasicArrowButton.addMouseListener(this);
        backBasicArrowButton.setCursor(handCursor);

        frame.setVisible(true);

    }// aboutFrame Method

    // This method encodes the data based on its index value
    public static byte[] encrypter(byte data[]) {

        byte[] encryptedData = new byte[data.length]; // Creating a new array of bytes with the same length as the
                                                      // original data

        // Loop to alter the contents of the byte array
        for (int i = 0; i < data.length; i++) {
            // If the index value is odd the following will occur
            if (i % 2 != 0) {
                encryptedData[i] = (byte) (data[i] + 3); // Adding 3 to its value
            }
            // If the index value is even the following will occur
            else {
                encryptedData[i] = (byte) (data[i] - 2); // Subtracting 2 from its value
            }
        }

        return encryptedData; // Returning the encrypted data

    }// encrypter Method

    // This method decodes the data based on its index value
    public static byte[] decrypter(byte data[]) {

        byte[] decryptedData = new byte[data.length]; // Creating a new array of bytes with the same length as the
                                                      // original data

        // Loop to alter the contents of the byte array
        for (int i = 0; i < data.length; i++) {
            // If the index value is odd the following will occur
            if (i % 2 != 0) {
                decryptedData[i] = (byte) (data[i] - 3); // Subtracting 3 from its value
            }
            // If the index value is even the following will occur
            else {
                decryptedData[i] = (byte) (data[i] + 2); // Adding 2 to its value
            }
        }

        return decryptedData; // Returing the decrypted value

    }// decrypter Method

    // This method will read from the selected file and store it as a byte array
    public static byte[] readFile(String filePath) {

        try {
            FileReader fileR = new FileReader(filePath);
            BufferedReader readFile = new BufferedReader(fileR);

            String data;

            while ((data = readFile.readLine()) != null) {
                return data.getBytes();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error has occured");
        }

        return null;

    }// readFile Method

    // This method will save the encrypted data to a file
    public static void fileOutput(byte[] data, String encOrDec) {

        String fileName;

        if (encOrDec.equals("enc")) {
            fileName = "encrypted.txt";
        } else {
            fileName = "decrypted.txt";
        }

        File file = new File(fileName);

        if (file.exists() && encOrDec.equals("enc")) {
            fileName = "secured.txt";
        } else if (file.exists() && encOrDec.equals("dec")) {
            fileName = "unsecured.txt";
        }

        FileWriter fileW;
        try {
            fileW = new FileWriter(fileName);
            PrintWriter output = new PrintWriter(fileW);

            String outputInfo = new String(data);
            output.println(outputInfo);
            output.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An unexpected error has occured");
        }

    }// fileOutput Method

    public void actionPerformed(ActionEvent event) {

        int value;

        if (event.getSource() == btnWelcome) {
            frameWelcome.dispose();
            menuFrame(frameMenu, btnEncrypt, btnDecrypt, btnAbout);
        } else if (event.getSource() == btnEncrypt) {
            frameMenu.dispose();
            encFrame(frameEncrypt, paneTxtEnc, btnSelectFile, btnSecure, lblEnc, lblOr, lblSelectFile, lblSelectedFile,
                    basicBtn);
        } else if (event.getSource() == btnSelectFile) {

            value = fChooser.showOpenDialog(encryption.this);

            if (value == JFileChooser.APPROVE_OPTION) {
                JOptionPane.showMessageDialog(null, fChooser.getSelectedFile().getName() + " has been selected");
                lblSelectedFile.setText(fChooser.getSelectedFile().getName());
            } else {
                JOptionPane.showMessageDialog(null, "File not selected");
            }
        } else if (event.getSource() == btnSecure) {
            if (lblSelectedFile.getText().length() == 0 && paneTxtEnc.getText().length() == 0) {

                JOptionPane.showMessageDialog(null, "No data has been entered for us to secure!");

            } else if (lblSelectedFile.getText().length() == 0 && paneTxtEnc.getText().length() > 0) {

                fileOutput(encrypter(paneTxtEnc.getText().getBytes()), "enc");
                JOptionPane.showMessageDialog(null, "Information Secured!", "SecureData by Shahrukh Qureshi",
                        JOptionPane.INFORMATION_MESSAGE, new ImageIcon("rsz_lock.png"));

            } else if (lblSelectedFile.getText().length() > 0 && paneTxtEnc.getText().length() == 0) {

                fileOutput(encrypter(readFile(fChooser.getSelectedFile().getPath())), "enc");
                JOptionPane.showMessageDialog(null, "Information Secured!", "SecureData by Shahrukh Qureshi",
                        JOptionPane.INFORMATION_MESSAGE, new ImageIcon("rsz_lock.png"));

            } else {

                byte[] array = readFile(fChooser.getSelectedFile().getPath());
                String byteToString = new String(array);
                String allInfo = byteToString + paneTxtEnc.getText();
                fileOutput(encrypter(allInfo.getBytes()), "enc");
                JOptionPane.showMessageDialog(null, "Information Secured!", "SecureData by Shahrukh Qureshi",
                        JOptionPane.INFORMATION_MESSAGE, new ImageIcon("rsz_lock.png"));

            }
        } else if (event.getSource() == btnDecrypt) {

            frameMenu.dispose();
            decFrame(frameEncrypt, btnSelectFile, btnUnsecure, lblDec, lblSelectedFile, basicBtn);

        } else if (event.getSource() == btnUnsecure) {

            if (lblSelectedFile.getText().length() == 0) {

                JOptionPane.showMessageDialog(null, "No data has been entered for us to unsecure!");

            } else if (lblSelectedFile.getText().length() > 0 && paneTxtEnc.getText().length() == 0) {

                fileOutput(decrypter(readFile(fChooser.getSelectedFile().getPath())), "dec");
                JOptionPane.showMessageDialog(null, "Information UnSecured!", "SecureData by Shahrukh Qureshi",
                        JOptionPane.INFORMATION_MESSAGE, new ImageIcon("rsz_109986.png"));

            }
        } else if (event.getSource() == basicBtn) {
            frameEncrypt.dispose();
            frameDecrypt.dispose();
            frameAbout.dispose();
            new encryption();
        } else if (event.getSource() == btnAbout) {
            frameMenu.dispose();
            aboutFrame(frameAbout, lblAuthor, lblGitHub, basicBtn, lblAboutTitle);
        }

        System.gc();
        Runtime.getRuntime().gc();

    }

    public void mouseClicked(MouseEvent eventClicked) {
        if (eventClicked.getSource() == lblGitHub) {
            try
            {
            Desktop d = Desktop.getDesktop();
            d.browse(new URI("https://github.com/ShaleeQureshi"));
            }
            catch (Exception error) {
                JOptionPane.showMessageDialog(null, "An error has occured!");
            } 
        }
    }

    public void mouseEntered(MouseEvent eMouseEvent) {

        if (eMouseEvent.getSource() == btnEncrypt) {
            btnEncrypt.setToolTipText("Click to Secure your Data!");
        } else if (eMouseEvent.getSource() == btnDecrypt) {
            btnDecrypt.setToolTipText("Click to UnSecure your Data!");
        } else if (eMouseEvent.getSource() == basicBtn) {
            basicBtn.setToolTipText("Click to go back");
        } else if (eMouseEvent.getSource() == btnSecure) {
            btnSecure.setToolTipText("Click to Secure your Data!");
        } else if (eMouseEvent.getSource() == btnUnsecure) {
            btnUnsecure.setToolTipText("Click to UnSecure your Data!");
        } else if (eMouseEvent.getSource() == btnSelectFile) {
            btnSelectFile.setToolTipText("Click to import a file!");
        }

    }

    public void mouseExited(MouseEvent arg0) {
    }

    public void mousePressed(MouseEvent arg0) {
    }

    public void mouseReleased(MouseEvent arg0) {
    }

    public static void main(String[] args) {

        new encryption();

    }// main Method

}// encryption Class