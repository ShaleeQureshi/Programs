This is an encryption/decryption program developed by Shahrukh Qureshi

Files needed for the program to run as expected:
-rsz_109986.png
-rsz_lock.png

The Manifest.txt is needed to create a NEW exe jar

Website: https://shaleequreshi2019.wixsite.com/website
GitHub: https://github.com/ShaleeQureshi